//  to controll ur website

const express = require("express");
const app = express();
const port = 5000;
app.set("view engine", "ejs");
app.use(express.static("public"));
app.use(express.urlencoded({ extended: true }));
const Article = require("./models/articleSchema");

const path = require("path");



const mongoose = require("mongoose");

mongoose
  .connect(
    "mongodb+srv://walid:dwd@cluster0.94l9asm.mongodb.net/walidos?retryWrites=true&w=majority"
  )
  .then((result) => {
    app.listen(port, () => {
      console.log(`RUN MY APP at http://localhost:${port}`);
    });
  })

  .catch((err) => {
    console.log(err);
  });

app.get("/", (req, res) => {
  res.redirect("/Login");
});

app.get("/all-articles", (req, res) => {
  // res.render("index", { mytitle: "HOME" });

  // result = Array of objects inside mongo database

  Article.find()
    .then((result) => {
      res.render("index", { mytitle: "HOME", arrArticle: result });
    })
    .catch((err) => {
      console.log(err);
    });
});

app.get("/add-new-user", (req, res) => {
  res.render("add-new-user", { mytitle: "Create new user" });
});


app.get("/update", (req, res) => {
  res.render("update", { mytitle: "Update user" });
});



app.get("/Login", (req, res) => {
  res.render("Login", { mytitle: "Login user" });
});


app.post("/all-articles", (req, res) => {
  const article = new Article(req.body);

  // console.log(req.body)

  article
    .save()
    .then((result) => {
      res.redirect("/all-articles");
    })
    .catch((err) => {
      console.log(err);
    });
});

app.get("/all-articles/:id", (req, res) => {
  

  Article.findById(req.params.id)
    .then((result) => {
      res.render("details", { mytitle: "User Details", objArticle: result });
    })
    .catch((err) => {
      console.log(err);
    });
});










app.delete("/all-articles/:id", (req, res) => {
  Article.findByIdAndDelete(req.params.id)
    .then((params) => { res.json({myLink:"/all-articles"}) })
    .catch((err) => {
      console.log(err);
    });
});



app.post("/edit", (req, res) => {
  
  const ID= req.body.id;
  const updatedUser={
    LastName: req.body.LastName,
        FirstName: req.body.FirstName,
        City: req.body.City,
        State: req.body.State,
        Gender: req.body.Gender,
        StudentStatus: req.body.StudentStatus,
        Major: req.body.Major,
        Country: req.body.Country,
        Age: req.body.Age,
        SAT: req.body.SAT,
        Grade: req.body.Grade,
        Height: req.body.Height

  }

  Article.updateOne({_id : ID}, {$set : updatedUser} , (error, doc)=>{
    if(error){
      console.log(error);
      res.redirect("/all-articles");
      return;
    }
    res.redirect("/all-articles");
  })
  
});





//  404
app.use((req, res) => {
  res.status(404).send("Sorry can't find this page!");
});
