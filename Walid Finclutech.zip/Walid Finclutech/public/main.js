{// dark
    const dark = document.getElementById("dark")
    const body = document.getElementById("body")
    
    
    dark.addEventListener("click", (eo) => {
      
      body.classList.toggle("dark")
    
    
    })}